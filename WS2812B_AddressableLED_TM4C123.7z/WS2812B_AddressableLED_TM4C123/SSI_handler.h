#include <stdint.h>
#include "tm4c123gh6pm.h"

void SSI0_DataOut(uint8_t data);
void SSI0_Init(void);
